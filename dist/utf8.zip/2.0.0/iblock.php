<?php

namespace Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Update;
 
$MESS['PROJECT_AJAX_NAME'] = 'project: Модуль ajax';