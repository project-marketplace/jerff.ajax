<?

define('TEMPLATES_IS_MAIN', true);
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
$APPLICATION->SetTitle("Develop");
?>
<?

$APPLICATION->IncludeComponent("project.ajax:wrapper", ".default", array(
    'PARAM' => array(
        'section' => 1,
        'element' => 1,
    )
));
?>

<? require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php"); ?>