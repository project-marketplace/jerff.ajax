<?php

namespace Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Modules;

use Exception,
    Bitrix\Main\Application,
    Bitrix\Main\Loader,
    Bitrix\Main\ModuleManager;

class Utility {
    /* db */

    public function createDbTable($table) {
        if (!Application::getInstance()->getConnection()->isTableExists($table::getTableName())) {
            $table::getEntity()->createDbTable();
        }
    }

    public function dropTable($table) {
        Application::getInstance()->getConnection()->dropTable($table::getTableName());
    }

    public function RunSqlBatch($file) {
        global $DB;
        $DB->RunSQLBatch($this->dir . '/' . $file);
    }

    /* exception */

    public function ThrowException($message) {
        global $APPLICATION;
        $APPLICATION->ResetException();
        $APPLICATION->ThrowException($message);
    }

}
