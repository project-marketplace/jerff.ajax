<?php

namespace Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility;

use Bitrix\Main\Data,
    Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Config;

class Cache {

    const IS_CACHE = true;
    const IS_DEBUG = false;
    const CACHE_DAY = 86400;
    const CACHE_HOUR = 3600;
    const CACHE_TIME = self::CACHE_HOUR;
    const CACHE_MINUTE = 60;
    const CACHE_DIR = '/project.tools/';

    static public function get($cacheId, $func, $time = self::CACHE_TIME) {
        if (!Config::isCache()) {
            return $func();
        }
        $cacheId = 'project.tools:' . $time . ':' . (is_array($cacheId) ? implode(':', $cacheId) : $cacheId);
        $cache = Data\Cache::createInstance();
        if ($cache->initCache($time, $cacheId, self::CACHE_DIR)) {
            if (Config::isCacheDebug()) {
                pre('get');
            }
            $arResult = $cache->getVars();
        } elseif ($cache->startDataCache()) {
            $arResult = $func();
            if (empty($arResult)) {
                if (Config::isCacheDebug()) {
                    pre('abortDataCache');
                }
                $cache->abortDataCache();
            } else {
                if (Config::isCacheDebug()) {
                    pre('set');
                }
            }
            $cache->endDataCache($arResult);
        }
        if (Config::isCacheDebug()) {
            pre($cacheId, $arResult);
        }
        return $arResult;
    }

}
