
module.exports = function (gulp, plugins, config, setting) {
    return function () {
        return gulp.src(config.build).pipe(plugins.clean());
    };
};