
module.exports = function (gulp, plugins, config, setting) {
    return function () {
        let path = config.path;
        path.push('./**');
        return gulp.src(path, {base: './'})
                .pipe(gulp.dest(plugins.path.join(config.build, setting.sourse)));
    };
};