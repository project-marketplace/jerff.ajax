
/**
 * Создает содержимое для файла версии
 *
 * @param version
 * @param date
 * @returns {string}
 */
const createVersionFileContent = (version, date) => {
    return `<?
$arModuleVersion = array(
\t"VERSION" => "${ version }",
\t"VERSION_DATE" => "${ date }"
);
?>`;
};

module.exports = function (gulp, plugins, config, setting) {
    return function () {
        const content = createVersionFileContent(setting.version, setting.date);
        return plugins.file('version.php', content, {src: true})
                .pipe(gulp.dest('install'));
    };
};