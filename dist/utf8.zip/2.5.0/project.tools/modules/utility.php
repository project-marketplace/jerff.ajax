<?php

namespace Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Modules;

use Exception,
    Bitrix\Main\Application,
    Bitrix\Main\Loader,
    Bitrix\Main\ModuleManager;

class Utility {
    /* db */

    public function createDbTable($table) {
        if (!Application::getInstance()->getConnection()->isTableExists($table::getTableName())) {
            $table::getEntity()->createDbTable();
        }
    }

    public function dropTable($table) {
        Application::getInstance()->getConnection()->dropTable($table::getTableName());
    }

    public function RunSqlBatch($file) {
        global $DB;
        $DB->RunSQLBatch($this->dir . '/' . $file);
    }

    /* exception */

    public function ThrowException($message) {
        global $APPLICATION;
        $APPLICATION->ResetException();
        $APPLICATION->ThrowException($message);
    }

}
