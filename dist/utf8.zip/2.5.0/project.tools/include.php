<?php

namespace Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools;

if (defined('Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Config' => $classPath . 'config.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
