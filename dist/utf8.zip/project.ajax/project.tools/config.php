<?php

namespace Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools;

class Config {

    static private $arParams = array(
        /* Отладка */
        'adminDebug' => [1],
        /* Кеширование */
        'isCacheDebug' => false,
        'isCache' => true,
        /* Каталог */
        'catalogPriceId' => 1,
        /* ватермарки */
        'isWarermark' => true,
        'warermarkPath' => '/images/warermark.png',
        'warermarkСoefficient' => 0.8,
    );

    static public function set($arParams) {
        self::$arParams = array_merge(self::$arParams, $arParams);
    }

    static public function setParams($key, $value) {
        self::$arParams[$key] = $value;
    }

    static public function __callStatic($name, $arguments) {
        return self::$arParams[$name] ?: false;
    }

}
