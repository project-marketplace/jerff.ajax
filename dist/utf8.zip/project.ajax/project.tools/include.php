<?php

namespace Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools;

if (defined('Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Config' => $classPath . 'config.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
