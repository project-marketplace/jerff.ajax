<?php

namespace Project\Tools;

if (defined('Project\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Tools\Config' => $classPath . 'config.php',
    'Project\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
