<div class="projects__wrap">
    <div class="projects__col-4">
        <a href="" class="projects__item--1"  style="background-image: url(/upload/iblock/083/08311c01fcd39d303e4f02f4ae670bc3.png);">
            <div class="projects__content">
                <div class="projects__title">New Loft</div>
                <div class="projects__text">Создание и продвижение сайта</div>
            </div>
        </a>
    </div>
    <div class="projects__col-4">
        <a href="" class="projects__item--2"  style="background-image: url(/upload/iblock/e76/e76cfd5f9a8f2c98ae2044a6426de96c.png);">
            <div class="projects__content">
                <div class="projects__title">Contemp в Москве</div>
                <div class="projects__text">Продвижение сайта и контекстаная реклама</div>
            </div>
        </a>
    </div>
    <a href="" class="projects__item--3"  style="background-image: url(/upload/iblock/57a/57a3a3612037b32f76ed3c0674bb11ae.png);">
        <div class="projects__content">
            <div class="projects__title">James Fenner Portfolio</div>
            <div class="projects__text">Создание сайта</div>
        </div>
    </a>
    <div class="projects__col-4">
        <a href="" class="projects__item--4"  style="background-image: url(/upload/iblock/cf8/cf8dbee982f7d01ae661c79bcec5dabd.png);">
            <div class="projects__content">
                <div class="projects__title">GREEN STORY</div>
                <div class="projects__text">Продвижение сайта и контекстаная реклама</div>
            </div>
        </a>
    </div>
    <a href="" class="projects__item--5"  style="background-image: url(/upload/iblock/7bc/7bc7eeeb74d2ffe90d60f8b284997d65.png);">
        <div class="projects__content">
            <div class="projects__title">X-Showroom Moscow</div>
            <div class="projects__text">Создание и продвижение сайта</div>
        </div>
    </a>
</div>
<div class="center">
    <div class="orange_bth last__btn">Посмотреть все наши работы</div>
    <div class="orange_bth vis__btn">Посмотреть все работы</div>
</div>