<?
require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/header.php");
$APPLICATION->SetTitle("Список");
?>
<ul>
    <li><a href="/project.ajax/ajax/">ajax</a></li>
    <li><a href="/project.ajax/form/">form</a></li>
</ul>
<? require($_SERVER["DOCUMENT_ROOT"] . "/bitrix/footer.php"); ?>