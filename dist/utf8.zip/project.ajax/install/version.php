<?
$arModuleVersion = array(
	"VERSION" => "2.0.0",
	"VERSION_DATE" => "2017-12-17 21:04:39"
);
?>