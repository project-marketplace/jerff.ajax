<?php

namespace Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools;

if (defined('Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Config' => $classPath . 'config.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
