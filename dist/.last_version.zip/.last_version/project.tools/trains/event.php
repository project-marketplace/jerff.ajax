<?

namespace Project\Verc32214deb03bae02c6c095c53e9efa6c0f203523\Tools\Trains;

use Exception;

trait Event {

    static private $isStart = array();

    static protected function evetType() {
        throw new Exception('���������� ��� �������');
    }

    static protected function start() {
        if (empty(self::$isStart[static::evetType()])) {
            self::$isStart[static::evetType()] = true;
            return true;
        } else {
            return false;
        }
    }

    static protected function stop() {
        unset(self::$isStart[static::evetType()]);
        return false;
    }

}
