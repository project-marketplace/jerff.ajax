<?php

namespace Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility;

use CFile,
    Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Config;

class Image {

    static private function isWatermark($ID) {
        return Config::isWarermark();
    }

    static public function watermark($ID, $width, $height, $watermark = false) {
        if (self::isWatermark($ID)) {
            if (empty($watermark)) {
                $watermark = Config::warermarkPath();
            }
            $path = cFile::GetPath($ID);
            $newPath = $_SERVER['DOCUMENT_ROOT'] . ($img = str_replace('/upload/', '/upload/resize_cache/warermark/' . sha1($watermark) . '/', $path));
            CFile::ResizeImageFile(
                    $_SERVER['DOCUMENT_ROOT'] . $path, $newPath, array('width' => $width, 'height' => $height), BX_RESIZE_IMAGE_PROPORTIONAL, array(
                "name" => "watermark",
                "position" => "center",
                "size" => "resize",
                'coefficient' => Config::warermark�oefficient(),
                "file" => $_SERVER['DOCUMENT_ROOT'] . $watermark
                    )
            );
            return $img;
        } else {
            return self::resize($ID, $width, $height);
        }
    }

    static public function resize($ID, $width, $height, $type = BX_RESIZE_IMAGE_PROPORTIONAL) {
        return CFile::ResizeImageGet($ID, array('width' => $width, 'height' => $height), $type, false)['src'];
    }

}
