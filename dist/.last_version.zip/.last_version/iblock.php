<?php

namespace Project\Ver5850d60b624dbf3313cf95daa53e01ee15038027\Tools\Update;
 
$MESS['PROJECT_AJAX_NAME'] = 'project: ������ ajax';