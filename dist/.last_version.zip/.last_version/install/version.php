<?
$arModuleVersion = array(
	"VERSION" => "1.1.0",
	"VERSION_DATE" => "2017-12-16 15:40:51"
);
?>