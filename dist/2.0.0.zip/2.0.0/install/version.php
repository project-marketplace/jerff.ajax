<?
$arModuleVersion = array(
	"VERSION" => "2.0.0",
	"VERSION_DATE" => "2017-12-18 00:04:39"
);
?>