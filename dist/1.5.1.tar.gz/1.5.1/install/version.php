<?
$arModuleVersion = array(
	"VERSION" => "1.5.1",
	"VERSION_DATE" => "2018-03-29 06:32:56"
);
?>