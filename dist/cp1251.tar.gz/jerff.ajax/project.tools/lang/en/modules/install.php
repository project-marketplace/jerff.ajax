<?php

$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_INSTALL_DB_ERROR'] = 'An error occurs during database installation. ERROR';
$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_UNINSTALL_DB_ERROR'] = 'An error occurs during database uninstallation. ERROR';
$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_INSTALL_FILES_ERROR'] = 'An error occurs during midule files installation. ERROR';
$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_UNINSTALL_FILES_ERROR'] = 'An error occurs during midule files uninstallation. ERROR';
