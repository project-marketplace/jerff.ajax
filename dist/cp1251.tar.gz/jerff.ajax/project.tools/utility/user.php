<?php

namespace Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility;

use CUser;

class User {

    static private $userId;

    static public function authorize($userId) {
        global $USER;
        self::$userId = CUser::GetID();
        $USER->Logout();
        $USER->Authorize($userId);
    }

    static public function logout() {
        global $USER;
        $USER->Logout();
        $USER->Authorize(self::$userId);
    }

}
