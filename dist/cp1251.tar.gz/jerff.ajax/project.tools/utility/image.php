<?php

namespace Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility;

use CFile,
    Bitrix\Main\Application,
    Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Config;

class Image {

    static private function isWatermark($ID) {
        return Config::isWarermark();
    }

    static public function watermark($ID, $width, $height, $watermark = false) {
        if (self::isWatermark($ID)) {
            if (empty($watermark)) {
                $watermark = Config::warermarkPath();
            }
            $path = cFile::GetPath($ID);
            $newPath = Application::getDocumentRoot() . ($img = str_replace('/upload/', '/upload/resize_cache/warermark/' . sha1($watermark) . '/', $path));
            CFile::ResizeImageFile(
                    Application::getDocumentRoot() . $path, $newPath, array('width' => $width, 'height' => $height), BX_RESIZE_IMAGE_PROPORTIONAL, array(
                "name" => "watermark",
                "position" => "center",
                "size" => "resize",
                'coefficient' => Config::warermarkCoefficient(),
                "file" => Application::getDocumentRoot() . $watermark
                    )
            );
            return $img;
        } else {
            return self::resize($ID, $width, $height);
        }
    }

    static public function resize($ID, $width, $height, $type = BX_RESIZE_IMAGE_PROPORTIONAL) {
        return CFile::ResizeImageGet($ID, array('width' => $width, 'height' => $height), $type, false)['src'];
    }

}
