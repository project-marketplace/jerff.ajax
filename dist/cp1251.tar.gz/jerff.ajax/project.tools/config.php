<?php

namespace Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools;

class Config {

    static private $arParams = array(
        /* ������� */
        'adminDebug' => [1],
        /* ����������� */
        'isCacheDebug' => false,
        'isCache' => true,
        /* ������� */
        'catalogPriceId' => 1,
        /* ���������� */
        'isWarermark' => true,
        'warermarkPath' => '/images/warermark.png',
        'warermark�oefficient' => 0.8,
    );

    static public function set($arParams) {
        self::$arParams = array_merge(self::$arParams, $arParams);
    }

    static public function setParams($key, $value) {
        self::$arParams[$key] = $value;
    }

    static public function __callStatic($name, $arguments) {
        return self::$arParams[$name] ?: false;
    }

}
