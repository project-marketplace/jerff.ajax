<?
$arModuleVersion = array(
	"VERSION" => "1.4.0",
	"VERSION_DATE" => "2018-03-26 18:18:25"
);
?>