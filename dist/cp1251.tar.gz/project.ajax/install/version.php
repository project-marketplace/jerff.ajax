<?
$arModuleVersion = array(
	"VERSION" => "2.5.0",
	"VERSION_DATE" => "2017-12-20 12:27:09"
);
?>