<?php

namespace Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools;

class Config {

    static private $arParams = array(
        /* ������� */
        'adminDebug' => [1],
        /* ����������� */
        'isCacheDebug' => false,
        'isCache' => true,
        /* ������� */
        'catalogPriceId' => 1,
        /* ���������� */
        'isWarermark' => true,
        'warermarkPath' => '/images/warermark.png',
        'warermark�oefficient' => 0.8,
    );

    static public function set($arParams) {
        self::$arParams = array_merge(self::$arParams, $arParams);
    }

    static public function setParams($key, $value) {
        self::$arParams[$key] = $value;
    }

    static public function __callStatic($name, $arguments) {
        return self::$arParams[$name] ?: false;
    }

}
