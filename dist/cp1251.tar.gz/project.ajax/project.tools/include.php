<?php

namespace Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools;

if (defined('Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Config' => $classPath . 'config.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
