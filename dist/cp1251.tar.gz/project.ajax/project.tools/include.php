<?php

namespace Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools;

if (defined('Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core') and !defined('Project\Debug\IS_START')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Config' => $classPath . 'config.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Lang' => $classPath . 'utility/lang.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
