<?php

namespace Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools;

if (defined('Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Config' => $classPath . 'config.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Ver357216e5eef716ca853998769fd747f5fa091b14\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
