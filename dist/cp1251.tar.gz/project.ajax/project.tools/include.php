<?php

namespace Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools;

if (defined('Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Config' => $classPath . 'config.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Verdeb1e012972b21585200abec7d009d16e58c5174\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
