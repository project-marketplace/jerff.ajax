<?

namespace Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Trains;

use Exception;

trait Event {

    static private $isStart = array();

    static protected function evetType() {
        throw new Exception('���������� ��� �������');
    }

    static protected function start() {
        if (empty(self::$isStart[static::evetType()])) {
            self::$isStart[static::evetType()] = true;
            return true;
        } else {
            return false;
        }
    }

    static protected function stop() {
        unset(self::$isStart[static::evetType()]);
        return false;
    }

}
