
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        plugins.sequence('clean', 'move', 'encode', 'archive', 'clean', callback);
    };
};