
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        plugins.sequence('build', function () {
            setting.file = '.last_version';
            gulp.src(plugins.path.join(config.build, setting.sourse, '**'))
                    .pipe(gulp.dest(plugins.path.join(config.build, setting.file)))
                    .on('end', function () {
                        plugins.sequence('clean_sourse', function () {
                            setting.sourse = setting.file;
                            plugins.sequence('archive', 'clean', callback);
                        });
                    });
        });
    };
};