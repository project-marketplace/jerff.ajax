<?php

$MESS['JERFF_AJAX_NAME'] = 'project: Модуль ajax';
$MESS['JERFF_AJAX_DESCRIPTION'] = '';
$MESS['JERFF_AJAX_PARTNER_NAME'] = 'jerff';
$MESS['JERFF_AJAX_PARTNER_URI'] = 'https://jerff.ru';