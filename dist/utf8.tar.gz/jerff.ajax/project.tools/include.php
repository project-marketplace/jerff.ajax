<?php

namespace Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools;

if (defined('Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!defined('Project\Debug\IS_START')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Config' => $classPath . 'config.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Lang' => $classPath . 'utility/lang.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
    'Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility\User' => $classPath . 'utility/user.php',
));
