<?php

$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_INSTALL_DB_ERROR'] = 'Произошла ошибка в процессе инсталляции БД модуля. ERROR';
$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_UNINSTALL_DB_ERROR'] = 'Произошла ошибка в процессе деинсталляции БД модуля. ERROR';
$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_INSTALL_FILES_ERROR'] = 'Произошла ошибка в процессе инсталляции файлов модуля. ERROR';
$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_UNINSTALL_FILES_ERROR'] = 'Произошла ошибка в процессе деинсталляции файлов модуля. ERROR';