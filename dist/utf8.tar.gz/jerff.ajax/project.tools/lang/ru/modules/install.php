<?php

$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_INSTALL_DB_ERROR'] = 'Произошла ошибка в процессе инсталляции БД модуля. ERROR';
$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_UNINSTALL_DB_ERROR'] = 'Произошла ошибка в процессе деинсталляции БД модуля. ERROR';
$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_INSTALL_FILES_ERROR'] = 'Произошла ошибка в процессе инсталляции файлов модуля. ERROR';
$MESS['Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools_UNINSTALL_FILES_ERROR'] = 'Произошла ошибка в процессе деинсталляции файлов модуля. ERROR';