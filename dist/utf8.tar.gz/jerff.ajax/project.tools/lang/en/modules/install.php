<?php

$MESS['Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools_INSTALL_DB_ERROR'] = 'An error occurs during database installation. ERROR';
$MESS['Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools_UNINSTALL_DB_ERROR'] = 'An error occurs during database uninstallation. ERROR';
$MESS['Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools_INSTALL_FILES_ERROR'] = 'An error occurs during midule files installation. ERROR';
$MESS['Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools_UNINSTALL_FILES_ERROR'] = 'An error occurs during midule files uninstallation. ERROR';
