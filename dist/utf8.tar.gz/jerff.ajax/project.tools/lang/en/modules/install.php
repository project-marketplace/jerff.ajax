<?php

$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_INSTALL_DB_ERROR'] = 'An error occurs during database installation. ERROR';
$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_UNINSTALL_DB_ERROR'] = 'An error occurs during database uninstallation. ERROR';
$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_INSTALL_FILES_ERROR'] = 'An error occurs during midule files installation. ERROR';
$MESS['Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools_UNINSTALL_FILES_ERROR'] = 'An error occurs during midule files uninstallation. ERROR';
