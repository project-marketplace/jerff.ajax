<?php

namespace Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility;

use Bitrix\Main\Localization\Loc;

class Lang {

    static private $path = '';

    static public function init($path) {
        self::$path = dirname($path);
    }

    static public function load($path) {
        Loc::loadCustomMessages(str_replace(self::$path, self::$path . '/lang/' . LANG_ID, $path));
    }

}
