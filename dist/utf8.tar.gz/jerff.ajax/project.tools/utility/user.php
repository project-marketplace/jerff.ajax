<?php

namespace Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Utility;

use CUser;

class User {

    static private $userId;

    static public function authorize($userId) {
        global $USER;
        self::$userId = CUser::GetID();
        $USER->Logout();
        $USER->Authorize($userId);
    }

    static public function logout() {
        global $USER;
        $USER->Logout();
        $USER->Authorize(self::$userId);
    }

}
