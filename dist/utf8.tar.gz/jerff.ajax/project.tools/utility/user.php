<?php

namespace Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility;

use CUser;

class User {

    static private $userId;

    static public function authorize($userId) {
        global $USER;
        self::$userId = CUser::GetID();
        $USER->Logout();
        $USER->Authorize($userId);
    }

    static public function logout() {
        global $USER;
        $USER->Logout();
        $USER->Authorize(self::$userId);
    }

}
