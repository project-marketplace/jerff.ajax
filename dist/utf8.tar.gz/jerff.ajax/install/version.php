<?
$arModuleVersion = array(
	"VERSION" => "2.6.1",
	"VERSION_DATE" => "2018-01-10 21:17:58"
);
?>