<?php

if (!defined('\Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Modules\IS_START')) {
    include_once(dirname(__DIR__) . '/project.tools/include.php');
}

use Bitrix\Main\Localization\Loc,
    Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Modules;

IncludeModuleLangFile(__FILE__);

class project_ajax extends CModule {

    public $MODULE_ID = 'project.ajax';
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;

    use Modules\Install;

    function __construct() {
        $this->setParam(__DIR__, 'PROJECT_AJAX');
        $this->MODULE_NAME = Loc::getMessage('PROJECT_AJAX_NAME');
        $this->MODULE_DESCRIPTION = Loc::getMessage('PROJECT_AJAX_DESCRIPTION');
        $this->PARTNER_NAME = Loc::getMessage('PROJECT_AJAX_PARTNER_NAME');
        $this->PARTNER_URI = Loc::getMessage('PROJECT_AJAX_PARTNER_URI');
    }

    public function DoInstall() {
        $this->Install();
    }

    public function DoUninstall() {
        $this->Uninstall();
    }

    /*
     * InstallFiles
     */

    public function InstallFiles($arParams = array()) {
        CopyDirFiles($_SERVER['DOCUMENT_ROOT'] . '/local/modules/' . $this->MODULE_ID . '/install/components/', $_SERVER['DOCUMENT_ROOT'] . '/local/components/', true, true);
        CopyDirFiles($_SERVER['DOCUMENT_ROOT'] . '/local/modules/' . $this->MODULE_ID . '/install/site/public/project.ajax', $_SERVER['DOCUMENT_ROOT'] . '/project.ajax/', true, true);
    }

    public function UnInstallFiles() {
        DeleteDirFiles($_SERVER['DOCUMENT_ROOT'] . '/local/modules/' . $this->MODULE_ID . '/install/components/', $_SERVER['DOCUMENT_ROOT'] . '/local/components/');
        DeleteDirFiles($_SERVER['DOCUMENT_ROOT'] . '/local/modules/' . $this->MODULE_ID . '/install/site/public/project.ajax', $_SERVER['DOCUMENT_ROOT'] . '/project.ajax/');
    }

}
