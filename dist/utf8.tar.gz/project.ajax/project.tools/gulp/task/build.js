
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        setting.file = 'utf8';
        setting.sourse = config.name;
        plugins.sequence('clean', 'move', 'tools', 'archive', function () {
            setting.file = 'cp1251';
            plugins.sequence('encode', 'archive', callback);
        });
    };
};