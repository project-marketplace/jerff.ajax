
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        setting.file = setting.sourse = '.last_version';
        plugins.sequence('build_encode', callback);
    };
};