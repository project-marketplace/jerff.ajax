
module.exports = function (gulp, plugins, config, setting) {
    // Инициализация версии
    gulp.task('version', ['version-tags', 'version-tools'], plugins.task('version'));

    // Теги
    gulp.task('version-tags', plugins.task('version-tags'));

    // Ревизии
    gulp.task('version-tools', plugins.task('version-tools'));

    // Очистка директории со сборкой
    gulp.task('clean', plugins.task('clean'));

    // Очистка директории со сборкой
    gulp.task('clean_sourse', plugins.task('clean_sourse'));

    // Копирование всех файлов модуля в директорию сборки
    gulp.task('move', ['version'], plugins.task('move'));

    // Перенос последней версии модуля в директорию сборки
    gulp.task('diff', ['version'], plugins.task('diff'));

    // Кодирование в 1251
    gulp.task('encode', plugins.task('encode'));

    // Архивирует в zip
    gulp.task('archive', plugins.task('archive'));

    // Заменяем подмодули
    gulp.task('tools', plugins.task('tools'));

    // Сборка текущей версии модуля
    gulp.task('build', plugins.task('build'));

    // Сборка текущей версии модуля
    gulp.task('build_last_version', plugins.task('build_last_version'));

    // Сборка обновления модуля (разница между последней и предпоследней версией по тегам git)
    gulp.task('build_update', plugins.task('build_update'));
};