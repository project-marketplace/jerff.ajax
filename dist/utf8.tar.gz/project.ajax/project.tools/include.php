<?php

namespace Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools;

if (defined('Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Config' => $classPath . 'config.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
