<?
$arModuleVersion = array(
	"VERSION" => "1.1.0",
	"VERSION_DATE" => "2018-03-17 07:38:58"
);
?>