<?php

namespace Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility;

use Bitrix\Main\Localization\Loc;

class Lang {

    static private $path = '';

    static public function init($path) {
        self::$path = dirname($path);
    }

    static public function load($path) {
        Loc::loadCustomMessages(str_replace(self::$path, self::$path . '/lang/' . LANG_ID, $path));
    }

}
