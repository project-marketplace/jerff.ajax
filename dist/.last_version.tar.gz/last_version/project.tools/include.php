<?php

namespace Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools;

if (defined('Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!Loader::includeModule('project.core') and !defined('Project\Debug\IS_START')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Config' => $classPath . 'config.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Lang' => $classPath . 'utility/lang.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Vera38e70efb77e232a68486b95884cb48a0d695773\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
));
