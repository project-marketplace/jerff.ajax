<?php

namespace Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools;

if (defined('Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\IS_START')) {
    return;
}

const IS_START = true;

use Bitrix\Main\Application,
    Bitrix\Main\Loader;

if (!defined('Project\Debug\IS_START')) {
    include_once(__DIR__ . '/debug.php');
}

$classPath = str_replace(Application::getDocumentRoot(), '', __DIR__ . '/');
Loader::registerAutoLoadClasses(null, array(
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Config' => $classPath . 'config.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Modules\Install' => $classPath . 'modules/install.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Modules\Utility' => $classPath . 'modules/utility.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Parse\Content' => $classPath . 'parse/content.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Parse\Image' => $classPath . 'parse/image.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Sale\Discount' => $classPath . 'sale/discount.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Trains\Event' => $classPath . 'trains/event.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Update\Catalog' => $classPath . 'update/catalog.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Update\Iblock' => $classPath . 'update/iblock.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Update\Property' => $classPath . 'update/property.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Update\Section' => $classPath . 'update/section.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Agent' => $classPath . 'utility/agent.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Cache' => $classPath . 'utility/cache.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Content' => $classPath . 'utility/content.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Highload' => $classPath . 'utility/highload.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Image' => $classPath . 'utility/image.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Lang' => $classPath . 'utility/lang.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Report' => $classPath . 'utility/report.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Request' => $classPath . 'utility/request.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\Sort' => $classPath . 'utility/sort.php',
    'Project\Verdd30653d8596c46422777ab9564a057b86915727\Tools\Utility\User' => $classPath . 'utility/user.php',
));
