<?php

namespace Project\Ver31641231210b819a50b8669ecba570fb84fe28b4\Tools\Modules;

use Exception,
    Bitrix\Main\Application,
    Bitrix\Main\Loader,
    Bitrix\Main\Localization\Loc,
    Bitrix\Main\ModuleManager;

class Utility {
    /* db */

    public function createDbTable($table) {
        if (!Application::getInstance()->getConnection()->isTableExists($table::getTableName())) {
            $table::getEntity()->createDbTable();
        }
    }

    public function dropTable($table) {
        Application::getInstance()->getConnection()->dropTable($table::getTableName());
    }

    public function RunSqlBatch($file) {
        global $DB;
        $DB->RunSQLBatch($this->dir . '/' . $file);
    }

    /* message */

    public function getMessage($message, $data = array()) {
        return Loc::getMessage($this->message . '_' . $message, $data);
    }

    /* exception */

    public function ThrowException($message, $data = array()) {
        global $APPLICATION;
        $APPLICATION->ResetException();
        $APPLICATION->ThrowException($this->getMessage($message), $data);
    }

}
