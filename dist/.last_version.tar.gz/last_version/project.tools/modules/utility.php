<?php

namespace Project\Vera6c44a537d4487f649cc59aea03627a78bf1f350\Tools\Modules;

use Exception,
    Bitrix\Main\Application,
    Bitrix\Main\Loader,
    Bitrix\Main\ModuleManager;

class Utility {
    /* db */

    public function createDbTable($table) {
        if (!Application::getInstance()->getConnection()->isTableExists($table::getTableName())) {
            $table::getEntity()->createDbTable();
        }
    }

    public function dropTable($table) {
        Application::getInstance()->getConnection()->dropTable($table::getTableName());
    }

    public function RunSqlBatch($file) {
        global $DB;
        $DB->RunSQLBatch($this->dir . '/' . $file);
    }

    /* exception */

    public function ThrowException($message) {
        global $APPLICATION;
        $APPLICATION->ResetException();
        $APPLICATION->ThrowException($message);
    }

}
