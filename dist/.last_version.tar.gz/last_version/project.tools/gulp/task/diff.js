
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        plugins.git.exec({args: `diff ${setting.version} --name-only`}, (error, output) => {
            if (error) {
                callback(error);
            }
            let path = [];
            output.split(plugins.os.EOL).map((file) => {
                if (!file.match(/(dist\/)/)) {
                    path.push(file);
                }
            });
            setting.file = setting.sourse = setting.version;
            gulp.src(path, {base: './'})
                    .pipe(gulp.dest(plugins.path.join(config.build, setting.sourse)))
                    .on('end', callback);
        });
    };
};