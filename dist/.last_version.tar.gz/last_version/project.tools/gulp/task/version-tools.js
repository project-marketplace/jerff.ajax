
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        plugins.git.exec({args: 'submodule status'}, (error, output) => {
            if (error) {
                throw error;
            }
            output.split(plugins.os.EOL).map((rev) => {
                rev = rev.trim().split(' ');
                if (config.tools[rev[1]]) {
                    let item = config.tools[rev[1]];
                    rev = rev[0].replace(/[^a-z0-9]/g, '');
                    setting.tools.push([item[0] + '\\' + item[1], item[0] + '\\Ver' + rev + '\\' + item[1]]);
                }
            });
            callback();
        });
    };
};