
module.exports = function (gulp, plugins, config, setting) {
    return function () {
        return gulp.src(plugins.path.join(config.build, setting.sourse)).pipe(plugins.clean());
    };
};