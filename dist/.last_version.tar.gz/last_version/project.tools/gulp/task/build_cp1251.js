
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        setting.file = 'cp1251';
        setting.sourse = config.name;
        plugins.sequence('build_encode', callback);
    };
};