
module.exports = function (gulp, plugins, config, setting) {
    return function (callback) {
        plugins.sequence('clean', function () {
            setting.file = setting.sourse = setting.version;
            plugins.sequence('diff', 'encode', 'archive', 'clean', callback);
        });
    };
};