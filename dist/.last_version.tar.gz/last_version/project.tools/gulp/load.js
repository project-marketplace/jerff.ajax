
module.exports = function (gulp, plugins, config, setting) {
    plugins.path = require('path');
    plugins.os = require('os');
    plugins.moment = require('moment');
    plugins.sequence = require('run-sequence');
    plugins.task = function (task) {
        return require('./task/' + task)(gulp, plugins, config, setting);
    };
    require('./logick')(gulp, plugins, config, setting);
};