<?php

namespace Project\Ver091f534bcb5e74f01d6a9589803c198b2604d9bb\Tools\Update;

use CIBlockPropertyEnum;

class Property {

    static $arResplace = array(
        '������' => '������',
        '������' => '������',
        '������' => '������',
        '������' => '������',
    );

    static public function setResplace($arResplace) {
        self::$arResplace = $arResplace;
    }

    public static function props($iblock, $propertyId, $name) {
        static $arProps = array();
        if (empty($arProps[$iblock][$propertyId])) {
            $arFilter = array(
                'IBLOCK_ID' => $iblock,
                'PROPERTY_ID' => $propertyId,
            );
            $res = CIBlockPropertyEnum::GetList(array(), $arFilter);
            while ($arItem = $res->Fetch()) {
                $arProps[$iblock][$propertyId][$arItem['VALUE']] = $arItem['ID'];
            }
        }
        if (isset(self::$arResplace[$name])) {
            $name = self::$arResplace[$name];
        }
        if (empty($arProps[$iblock][$propertyId][$name])) {
            preExit($iblock, $propertyId, $name);
        }
        return $arProps[$iblock][$propertyId][$name];
    }

}
