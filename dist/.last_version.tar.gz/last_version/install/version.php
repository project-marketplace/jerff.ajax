<?
$arModuleVersion = array(
	"VERSION" => "1.2.0",
	"VERSION_DATE" => "2018-03-25 20:23:32"
);
?>