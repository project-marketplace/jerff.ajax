<?
$arModuleVersion = array(
	"VERSION" => "1.1.0",
	"VERSION_DATE" => "2018-03-22 21:49:06"
);
?>