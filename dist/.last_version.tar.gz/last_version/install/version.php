<?
$arModuleVersion = array(
	"VERSION" => "1.5.0",
	"VERSION_DATE" => "2018-03-27 17:38:44"
);
?>