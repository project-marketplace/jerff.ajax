<?
$arModuleVersion = array(
	"VERSION" => "1.3.0",
	"VERSION_DATE" => "2018-03-17 08:03:46"
);
?>