<div class="best__left-block best__lf--js">
    <div class="active best__lf-item-js best__lf-item-mobile">
        <div class="best__list--img">
            <img class="it__1" src="images/best/reason1-icon.svg">
        </div>
        <div class="best__list--title">�������������� ����������� ������</div>
        <div class="best__list--text">Crasjusto ducimus qui cupiditate non provident, similique sunt in culpaid est anditiis praesentium praesentium blanditiis praesentium non provident, similique sunt in culpaid est a...</div>
    </div>
    <div class="best__lf-item-js best__lf-item-mobile">
        <div class="best__list--img">
            <img class="it__2" src="images/best/reason2-icon.svg">
        </div>
        <div class="best__list--title">�������� </div>
        <div class="best__list--text">Crasjusto ducimus qui cupiditate non provident, similique sunt in culpaid est anditiis praesentium praesentium blanditiis praesentium non provident, similique sunt in culpaid est a...</div>
    </div>
    <div class="best__lf-item-js best__lf-item-mobile">
        <div class="best__list--img">
            <img class="it__3" src="images/best/reason3-icon.svg">
        </div>
        <div class="best__list--title">����������� ������, ����, �������</div>
        <div class="best__list--text">Crasjusto ducimus qui cupiditate non provident, similique sunt in culpaid est anditiis praesentium praesentium blanditiis praesentium non provident, similique sunt in culpaid est a...</div>
    </div>
    <div class="best__lf-item-js best__lf-item-mobile">
        <div class="best__list--img">
            <img src="images/best/reason4-icon.svg">
        </div>
        <div class="best__list--title">������� �������� 3 ����</div>
        <div class="best__list--text">Crasjusto ducimus qui cupiditate non provident, similique sunt in culpaid est anditiis praesentium praesentium blanditiis praesentium non provident, similique sunt in culpaid est a...</div>
    </div>
</div>
