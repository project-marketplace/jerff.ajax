
module.exports = function (gulp, plugins, config, setting) {
    return function () {
        let sourse = setting.file ? setting.file : setting.sourse
        return gulp.src(plugins.path.join(config.build, '**/*'), {dot: true})
                .pipe(plugins.zip(sourse + '.zip', {compress: true}))
                .pipe(gulp.dest(config.dist));
    };
};