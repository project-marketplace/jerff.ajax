<?php

namespace Project\Verf4aad71cb04e76a0816b4c8e1f41426f48841b7c\Tools\Utility;

class Content {

    static public function translate($str) {
        static $t = array('/' => '-', '�' => 'a', '�' => 'b', '�' => 'v', '�' => 'g', '�' => 'd', '�' => 'e', '�' => 'jo', '�' => 'gh', '�' => 'z', '�' => 'i',
            '�' => 'j', '�' => 'k', '�' => 'l', '�' => 'm', '�' => 'n', '�' => 'o', '�' => 'p', '�' => 'r', '�' => 's', '�' => 't', '�' => 'u', '�' => 'f',
            '�' => 'x', '�' => 'c', '�' => 'ch', '�' => 'sh', '�' => 'th', '�' => '', '�' => '', '�' => 'y', '�' => 'eh', '�' => 'ju', '�' => 'ja');

        $new = '';
        $str = mb_strtolower(trim($str), 'UTF-8');
        $str = preg_replace('~\s~S', '_', $str);
        for ($i = 0, $c = mb_strlen($str, 'UTF-8'); $i < $c; $i++) {
            $s = mb_substr($str, $i, 1, 'UTF-8');
            if (isset($t[$s]))
                $new .= $t[$s];
            else if ((ord($s) > 126) or ( ord($s) == 20))
                $new .= '_';
            else
                $new .= $s;
        }
        return $new;
    }

    static public function toWin1251($arItem) {
        return array_map('trim', array_map(function($v) {
                    return iconv('UTF-8', 'WINDOWS-1251', $v);
                }, $arItem));
    }

    static public function toUtf8($arItem) {
        return array_map('trim', array_map(function($v) {
                    return iconv('WINDOWS-1251', 'UTF-8', $v);
                }, $arItem));
    }

}
