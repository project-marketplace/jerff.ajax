
module.exports = function (gulp, plugins, config, setting) {
    return function () {
        return gulp.src([
            plugins.path.join(config.build, setting.sourse, '**/*.php'),
            plugins.path.join(config.build, setting.sourse, '**/*.js')
        ], {dot: true})
                .pipe(plugins.iconv({encoding: 'win1251', decoding: 'utf8'}))
                .pipe(gulp.dest(plugins.path.join(config.build, setting.sourse)));
    };
};